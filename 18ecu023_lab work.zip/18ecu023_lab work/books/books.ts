export const books = [
    {title:"Let us C",price:120.00, pub:"TMH",ed:2018}
    
    
    
];